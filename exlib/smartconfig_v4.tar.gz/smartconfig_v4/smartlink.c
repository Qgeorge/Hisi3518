#include "smartconfig.h"
int main(int argc, char **argv) {

	router_login_info_p router_msg = NULL;	
	smartlink_start(&router_msg);
	if(router_msg!=NULL){
		printf("user:%s\npasswd:%s\n",
				router_msg->usrname,
				router_msg->passwd);
	}
	exit(1);
}
